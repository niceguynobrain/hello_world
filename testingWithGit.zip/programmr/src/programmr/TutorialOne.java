package programmr;

import java.util.*;

public class TutorialOne {

	/* Get the square root of a number */
	/**
	 * ask user for a number & give answer. Allow 4 uses, display message at
	 * end. display error message if not-a-number entered
	 */

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		int count = (0);
		int maxTries = 3;

		// While Loop use to give limited number of tries. More than one, less
		// than infinity.
		while (true) {
			// Try - Catch, used to stop program from crashing if character
			// entered instead of number.
			try {
				int num = 0;

				System.out.println("Enter a number: ");

				num = new Scanner(System.in).nextInt();

				// Equation
				long answer = num * num * num;

				// Answer
				System.out.println("The square root of " + num + " is "
						+ answer);

				// Limit number of tries.
				if (++count > maxTries) {
					Enough();
					return;
				}
			} catch (InputMismatchException exception) {
				// catch user error.
				System.out.println("Oops. This is not an number!");
			} finally {
				// include a message of how many tries left.
				if (4 - count > 0) {
					System.out.println("You have " + (4 - count)
							+ " remaining.\r");
				} else {
					System.out.println("Game over!");
				}
			}

		}
	}

	// Tell user why program stopped.
	// Put outside the main method for potential multiple uses.
	private static void Enough() {
		System.out.println("\n We have reached the end.");
		return;
	}

}
