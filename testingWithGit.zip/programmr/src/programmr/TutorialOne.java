package programmr;

import java.util.*;

public class TutorialOne {

	/* Get the square root of a number */
	/**
	 * ask user for a number & give answer. Allow 4 uses, display message at
	 * end. display error message if not-a-number entered
	 */

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		int count = 0;
		int maxTries = 4;
		double num = 0;
		
		while (true) {
			while (num == 0) {
				try {
					System.out.println("Enter a number: ");
					num = new Scanner(System.in).nextDouble();
					count++;

				} catch (InputMismatchException exception) {
					// catch user error.
					System.out.println("Oops. This is not an number!");
				}
			}
			// Equation
			double answer = num * num * num;
			// Answer
			System.out.println("The square root of " + num + " is " + answer);
			
			// Reassign to zero to prevent infinte loop.
			num = 0;

			// Limit number of tries.
			if (count >= maxTries) {
				System.out.println("\n We have reached the end. \n Game Over!");
				return;
			}

			// include a message of how many tries left.
			System.out.println("You have " + (maxTries - count)
					+ " remaining.\r");

		}

	}

}
